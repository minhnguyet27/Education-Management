from odoo import models, fields

class FormDiary(models.Model):
    _name = 'form.diary'
    _description = ''

    date_start = fields.Date(string='Từ', required=True, default=fields.Date.today)
    date_end = fields.Date(string='Đến', required=True, default=fields.Date.today)
    # source_id = fields.Many2one('account.source', string='Nguồn')
    source_id = fields.Char( string='Nguồn')
    program_id = fields.Char( string='Chương')
    # program_id = fields.Many2one('account.program', string='Chương')
    section_id = fields.Char( string='Khoản')
    # section_id = fields.Many2one('account.section', string='Khoản')
    filter_type = fields.Selection([
        ('all', 'Tất cả'),
        ('summary', 'Tổng hợp'),
        ('custom', 'Tùy chọn')
    ], string='Loại bộ lọc', default='all')
    combine_entries = fields.Boolean(string='Cộng gộp các bút toán giống nhau', default=False)
    template = fields.Selection([
        ('107', 'Thông tư 107/2017/TT-BTC'),
        ('other', 'Mẫu khác')
    ], string='Mẫu báo cáo', required=True, default='107')

    def action_save(self):
        self.ensure_one()
        # Thông báo thành công
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Thành công',
                'message': 'Dữ liệu đã được lưu.',
                'type': 'success',
                'sticky': False,
            },
        }
